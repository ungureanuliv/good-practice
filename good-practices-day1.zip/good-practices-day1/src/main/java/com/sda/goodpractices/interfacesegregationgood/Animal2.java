package com.sda.goodpractices.interfacesegregationgood;

public interface Animal2 {

    void eat();

    void makeSound();
}
