package com.sda.goodpractices.dependencyinversiongood;

public class Engine2 {
}
