package com.sda.goodpractices.interfacesegregationgood;

public interface RunnerAnimal {

    void run();
}
