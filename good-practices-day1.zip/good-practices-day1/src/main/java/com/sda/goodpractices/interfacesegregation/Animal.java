package com.sda.goodpractices.interfacesegregation;

public interface Animal {

    void makeSound();
    void run();

    void fly();

    void swim();

    void eat();
}
