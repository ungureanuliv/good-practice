package com.sda.goodpractices.interfacesegregationgood;

public class Dog implements Animal2, RunnerAnimal, SwimmerAnimal {
    @Override
    public void eat() {

    }

    @Override
    public void makeSound() {

    }

    @Override
    public void run() {

    }

    @Override
    public void swim() {

    }
}
