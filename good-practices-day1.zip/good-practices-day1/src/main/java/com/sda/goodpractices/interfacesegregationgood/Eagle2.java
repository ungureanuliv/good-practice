package com.sda.goodpractices.interfacesegregationgood;


public class Eagle2 implements Animal2, FlyerAnimal, RunnerAnimal {
    @Override
    public void makeSound() {

    }

    @Override
    public void run() {

    }

    @Override
    public void fly() {

    }

    @Override
    public void eat() {

    }
}
