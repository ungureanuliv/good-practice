package com.sda.goodpractices.builder;

public class ToyStoreApp {

    public static void main(String[] args) {
        Toy carToy = new Toy("Blue Car", "The perfect toy for car lovers", "blue",
                "plastic", 15, 25, 10, 200);

        // 1. to many params can cause to create objects with values in wrong order
        // we've switched the madeFrom with the color by mistake...
        Toy carToy2 = new Toy("Blue Car", "The perfect toy for car lovers",
                "plastic" , "blue", 15, 25, 10, 200);



        // 5. use the builder, note, the construct with a lot of params should be deleted,
        // but we keep it here so that the above lines also compile.

        Toy.ToyBuilder builder = new Toy.ToyBuilder();

        builder.setName("Blue Car")
                .setDescription("The perfect toy for car lovers")
                .setColor("blue")
                .setMadeFrom("plastic")
                .setWeight(200)
                .setWidth(10)
                .setLength(25)
                .setHeight(15); // please note, that there's not ; between the multiple invocations of the methods.

        Toy car3 = builder.build();

    }
}
