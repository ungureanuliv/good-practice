package com.sda.goodpractices.adapter;

import java.util.List;

public interface Student {

    String getFullName();
    String getContactDetails();

    boolean isAdult();

    List<Integer> getResults();
}
