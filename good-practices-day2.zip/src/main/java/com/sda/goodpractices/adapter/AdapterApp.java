package com.sda.goodpractices.adapter;

import java.util.ArrayList;
import java.util.List;

public class AdapterApp {

    public static void main(String[] args) {

        List<Integer> resuts  = new ArrayList<>();
        resuts.add(10);
        resuts.add(8);

        Student student1 = new BasicStudent("John Doe", "john@google.com", true, resuts);



        List<Student> students = new ArrayList<>();
        students.add(student1);

        // if we want to use the old model in the list of students we can't
        int[] grades = new int[] {9,9,6};

        Pupil pupil1 = new Pupil();
        pupil1.setFirstName("Jane");
        pupil1.setLastName("Doe");
        pupil1.setAge(19);
        pupil1.setEmail("jane@google.com");
        pupil1.setGrades(grades);

        // students.add(pupil1); // doesn't work.. 

    }
}
