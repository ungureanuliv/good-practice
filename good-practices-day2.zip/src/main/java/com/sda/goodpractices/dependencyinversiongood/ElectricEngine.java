package com.sda.goodpractices.dependencyinversiongood;

public class ElectricEngine extends Engine2{
}
