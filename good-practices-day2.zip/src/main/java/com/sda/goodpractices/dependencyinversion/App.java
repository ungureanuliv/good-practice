package com.sda.goodpractices.dependencyinversion;

public class App {

    public static void main(String[] args) {
        Car myCar = new Car();
        // myCar has an engine that I can't upgrade...
    }
}
