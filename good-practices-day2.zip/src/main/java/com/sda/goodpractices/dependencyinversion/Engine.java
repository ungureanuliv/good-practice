package com.sda.goodpractices.dependencyinversion;

public class Engine {
}
