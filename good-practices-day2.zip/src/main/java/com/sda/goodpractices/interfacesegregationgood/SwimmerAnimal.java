package com.sda.goodpractices.interfacesegregationgood;

public interface SwimmerAnimal {

    void swim();
}
