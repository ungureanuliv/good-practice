package com.sda.goodpractices.interfacesegregationgood;

public interface FlyerAnimal {

    void fly();
}
