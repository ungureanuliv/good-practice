package com.sda.goodpractices.singleton;

public class Student {

    private String name;

    public Student(String name) {
        this.name = name;
        Logger logger = Logger.getInstance();
        System.out.println("From constructor: "+logger);
        logger.debug("Creating a student named: "+name);
    }
}
