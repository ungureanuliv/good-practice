package com.sda.goodpractices.singleton;

public class SingletonApp {

    public static void main(String[] args) {
        // Logger logger = new Logger(); // doesn't work because constructor is private

        Logger logger = Logger.getInstance(); // Use class name! Because the method is static
        System.out.println("From main: "+logger);

        logger.info("This is a message from the main method!");
        Student student = new Student("John D.");

    }
}
